North Logo Package
==================
north-logo.svg      - Full color logo (SVG)
north-logo-dark.svg - Light variant for dark backgrounds
north-logo-light.svg - Dark variant for light backgrounds
north-logo.png      - Full color logo (PNG, 800px)
north-icon.svg      - Icon mark only (SVG)
