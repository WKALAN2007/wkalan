NORTH LOGO PACKAGE
==================
Contents:
  north-logo.svg        — Full color wordmark (dark text, transparent bg)
  north-logo-light.svg  — Light variant for dark backgrounds
  north-icon.svg        — Icon mark only ("N" in circle)

Formats: SVG (vector, scalable to any size)
For PNG/EPS versions, contact press@north.memory

Usage:
  - Maintain clear space equal to the height of the "N"
  - Do not stretch, skew, or recolor
  - Minimum digital size: 120px wide
  - Minimum print size: 25mm wide
