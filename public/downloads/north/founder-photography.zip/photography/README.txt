NORTH FOUNDER PHOTOGRAPHY
==========================
Portrait and candid photography of the North founding team.

Contents:
  david-kim-portrait.jpg     — David Kim, Founder & CEO
  david-kim-candid.jpg       — David Kim at the Portland office
  sarah-okafor-portrait.jpg  — Sarah Okafor, Co-founder & Design
  team-group.jpg             — Full founding team (18 members)

For high-resolution versions or specific shot requests:
  press@north.memory

Usage terms:
  Founder portraits may be used for editorial purposes
  (news articles, profiles, interviews) without prior permission.
  Please credit the photographer where noted.
